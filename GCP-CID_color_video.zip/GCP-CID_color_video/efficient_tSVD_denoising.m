function [denoised_video] = efficient_tSVD_denoising(noisy_video,U, V, ps, N_step_spatial, SR, maxK, sigma)
%CVMSTSVD_DENOISING �˴���ʾ�йش˺�����ժҪ

[H,W,~,D] = size(noisy_video);
info1 = int32([H,W,D]);
N_step_time = 1;
info2 = [ps,N_step_spatial,N_step_time,SR,maxK];
info2 = int32(info2);
tau = 1.1;
modified = 1;
info3 = [tau,modified,sigma];

denoised_video = color_video_denoising(single(noisy_video),single(U),single(V),info1,info2,single(info3));
denoised_video = mat_ten(denoised_video,1,size(noisy_video));

end

