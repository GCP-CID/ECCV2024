%% Demo simple write video
% % ������Ƶд����
% outputVideo = VideoWriter( fullfile(  'C:\Users\53162\Documents\MATLAB\Code\Video_denoising\CVMSt-SVD', 'test.avi' ) );
% % ����д����
% open( outputVideo )
% % ׼��ͼ��
% for i = 1 : size(denoised_MSTSVD,4)
%     img = uint8(denoised_MSTSVD(:,:,:,i));
%     % imshow( img )
%     writeVideo( outputVideo, img )  % д��
% end
% % �ر�д������ʹ��Ƶ��Ч
% close(outputVideo)

%% Write results of IOCV

% load Patch Representation;
load U;load V;
cur_path = pwd;

% Addpath
addpath('mex');
addpath('t_svd_lib');
video_path = 'D:\Data\Video_data\IOCV\OPPO_R11s\BC\';
write_path = 'D:\Code\denoise\Video_denoising\Traditional_methods\result_images\CVMStSVD_RGGB\IOCV';

addpath(video_path);
addpath(write_path);

noisy_name = dir(fullfile(video_path, '*noisy.avi'));
clean_name = dir(fullfile(video_path, '*mean_filter_mean.avi'));
num_videos = length(noisy_name);

% Parameters
ps = 8; SR = 16; maxK = 30; N_step_spatial = 6;N_step_time = 1;
tau = 1.1;  modified = 1; global_learning = 1;

% Select implementation
method = 'CVMStSVD_RGGB';


for i = 1:num_videos
    
    noisy_i = noisy_name(i).name;
    noisy_video = load_video(noisy_i);
    
    mean_i = clean_name(i).name;
    mean_video = load_video(mean_i);
    disp(noisy_i)
    
    noisy_video = single(noisy_video); mean_video = single(mean_video);
    
    
    denoised_MSTSVD = denoised_all{i};
  
    cd(write_path)
    S = split(noisy_i,'.');
    write_name = strcat(S{1},'_CVMStSVD_RGGB.avi');
    write_video_my(denoised_MSTSVD, write_name);
    cd(cur_path);
    
end





% Write video
function write_video_my(video, write_name)

outputVideo = VideoWriter(write_name);
% ����д����
open( outputVideo )

for i = 1 : size(video,4)
    img = uint8(video(:,:,:,i));
    % imshow( img )
    writeVideo( outputVideo, img )  % д��
end
% �ر�д������ʹ��Ƶ��Ч
close(outputVideo)

end

% Load video
function noisy_video = load_video(video_name)

video_noisy = VideoReader(video_name);
k = 1;
while hasFrame(video_noisy)
    vidFrame_noisy = readFrame(video_noisy);
    noisy_video(:,:,:,k) = vidFrame_noisy;
    k = k+1;
end

end