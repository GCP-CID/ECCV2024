% load Patch Representation;
load U;load V;
cur_path = pwd;

% Addpath
addpath('mex');
addpath('t_svd_lib');
video_path = 'D:\Data\Video_data\IOCV\HUAWEI_HONOR_6X\FC\';
% write_path = 'D:\Code\denoise\Video_denoising\result_images\CVMStSVD\IOCV';

addpath(video_path);
% addpath(write_path);

noisy_name = dir(fullfile(video_path, '*noisy.avi'));
clean_name = dir(fullfile(video_path, '*mean_filter_mean.avi'));
num_videos = length(noisy_name);

% Parameters
ps = 8; SR = 16; maxK = 30; N_step_spatial = 6;N_step_time = 1;
tau = 1.1;  modified = 1; global_learning = 1;

% Select implementation
method = 'mex_CVMStSVD';

% Choose optimal noise value as input
disp(['*******************',video_path,'**********************']);
noise_model = [10, 20, 30, 40, 50];
% sigma = select_best_sigma(noise_model, noisy_name, clean_name);
sigma = 40;
disp('****************************************************************')
disp(['method_used = ', method, ' best sigma value for ', video_path,' is: ',num2str(sigma)]);
disp('****************************************************************')

psnr_all = 0; ssim_all = 0;
psnr_noisy_all = 0; ssim_noisy_all = 0; elapsed_time = 0;

for i = 1:2
    noisy_i = noisy_name(i).name;
    noisy_video = load_video(noisy_i);
    
    mean_i = clean_name(i).name;
    mean_video = load_video(mean_i);
    disp(noisy_i)
    
    noisy_video = single(noisy_video); mean_video = single(mean_video);
    
    [psnr_noisy_i, ssim_noisy_i] = cal_video_metrics_my(mean_video/255, noisy_video/255);
    psnr_noisy_all = psnr_noisy_all + psnr_noisy_i;
    ssim_noisy_all = ssim_noisy_all + ssim_noisy_i;
    
    tic;
    
%     if strcmp(method, 'mex_CVMStSVD') == 1
%         [H,W,~,N] = size(noisy_video);
%         info1 = int32([H,W,N]);
%         info2 = [ps,N_step_spatial,N_step_time,SR,maxK];
%         info2 = int32(info2);
%         info3 = [tau,modified,sigma];
%         denoised_MSTSVD = color_video_denoising(single(noisy_video),single(U),single(V),info1,info2,single(info3));
%         denoised_MSTSVD = mat_ten(denoised_MSTSVD,1,size(noisy_video));
%     elseif strcmp(method, 'Matlab_CVMStSVD') == 1
%         denoised_MSTSVD = CVMStSVD_denoising_MATLAB(single(noisy_video), single(U), single(V), ps, N_step_spatial, N_step_time, SR, maxK, sigma, tau);
%     elseif strcmp(method, 'CVMStSVD_RGGB') == 1
%         denoised_MSTSVD = CVMStSVD_RGGB(single(noisy_video), single(U), single(V), ps, N_step_spatial, N_step_time, SR, maxK, sigma, tau, global_learning);
%     end
    
    denoised_MSTSVD = denoised_all{i};
    
    time = toc;
    elapsed_time = elapsed_time + time;
    
    [psnr_i, ssim_i] = cal_video_metrics_my(mean_video/255, denoised_MSTSVD/255);
    psnr_all = psnr_all + psnr_i;
    ssim_all = ssim_all + ssim_i;
    
    disp(['i = ',num2str(i), ' time = ',num2str(time), ' psnr_noisy = ',num2str(psnr_noisy_i), ' ssim_noisy = ',num2str(ssim_noisy_i), ' psnr_predicted = ',num2str(psnr_i), ' ssim_predicted = ',num2str(ssim_i)])
    
%     cd(write_path)
%     S = split(noisy_i,'.');
%     write_name = strcat(S{1},'_CVMStSVD_new.avi');
%     write_video(denoised_MSTSVD, write_name);
%     cd(cur_path);
    
end

avg_psnr_predicted = psnr_all/i; avg_ssim_predicted = ssim_all/i;
avg_psnr_noisy = psnr_noisy_all/i; avg_ssim_noisy = ssim_noisy_all/i;
avg_elapsed_time = elapsed_time / i;

% disp(['noise level = ',num2str(sigma),' avg_psnr_noisy = ',num2str(avg_psnr_noisy),' avg_ssim_noisy = ',num2str(avg_ssim_noisy), ' avg_psnr_predicted = ',num2str(avg_psnr_predicted), ' avg_ssim_predicted = ',num2str(avg_ssim_predicted)])
disp('############################## print statistics #####################################')
disp(['noise level = ',num2str(sigma), ' avg_elapsed_time = ', num2str(avg_elapsed_time), ' avg_psnr_noisy = ', num2str(avg_psnr_noisy), ' avg_psnr_denoised = ', num2str(avg_psnr_predicted), ' avg_ssim_noisy = ', num2str(avg_ssim_noisy), ' avg_ssim_denoised = ', num2str(avg_ssim_predicted)]);
disp('############################## print statistics #####################################')

for loop = 1:2
    for i = 1:size(noisy_video,4)
        subplot(121)
        imshow(single(mean_video(:,:,:,i))/255*1.18);title('Noisy Video');
        subplot(122)
        imshow(denoised_MSTSVD(:,:,:,i)/255*1.18);title('denoised');
        pause(0.06);
    end
end

% Cal_metrics (PSNR and SSIM)
function [psnr, ssim] = cal_video_metrics_my(denoised, origin)

sum_psnr = 0; sum_ssim = 0;
num_frames = size(denoised,4);

for i = 1:num_frames
    denoised_i = denoised(:,:,:,i);
    origin_i = origin(:,:,:,i);
    
    [psnr_i, ssim_i] = calculate_one_frame(double(denoised_i), double(origin_i));
    
    sum_psnr = sum_psnr + psnr_i;
    sum_ssim = sum_ssim + ssim_i;
end

psnr = sum_psnr / num_frames;
ssim = sum_ssim / num_frames;


end

function [PSNR, SSIM] = calculate_one_frame(denoised, clean)
 PSNR = 10*log10(1/mean((clean(:)-double(denoised(:))).^2));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculate MMSIM value
K = [0.01 0.03];
window = fspecial('gaussian', 11, 1.5);
L = 1;
[mssim1, ~] = ssim_index(denoised(:,:,1),clean(:,:,1),K,window,L);
[mssim2, ~] = ssim_index(denoised(:,:,2),clean(:,:,2),K,window,L);
[mssim3, ~] = ssim_index(denoised(:,:,3),clean(:,:,3),K,window,L);
SSIM = (mssim1+mssim2+mssim3)/3.0;

end


% Write video
function write_video(video, write_name)

outputVideo = VideoWriter(write_name);
% ����д����
open( outputVideo )

for i = 1 : size(video,4)
    img = uint8(video(:,:,:,i));
    % imshow( img )
    writeVideo( outputVideo, img )  % д��
end
% �ر�д������ʹ��Ƶ��Ч
close(outputVideo)

end

% Load video
function noisy_video = load_video(video_name)

video_noisy = VideoReader(video_name);
k = 1;
while hasFrame(video_noisy)
    vidFrame_noisy = readFrame(video_noisy);
    noisy_video(:,:,:,k) = vidFrame_noisy;
    k = k+1;
end

end
